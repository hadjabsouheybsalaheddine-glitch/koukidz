# KouKidz — prototype v1
Prototype de la première interface mobile KouKidz.
Style: Bordeaux + blanc + doré.
Étape suivante: transformer cette interface en vraie application Android/iOS, puis ajouter compte, catalogue, panier, commandes et backend.
